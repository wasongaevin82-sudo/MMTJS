package com.mmtjs.app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText learnerName, grade, amount, paymentMethod;
    private TextView slipNumber;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("mmtjs_receipts", MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("MAMA TETU JUNIOR SCHOOL\\nPAYMENT SLIP");
        title.setTextSize(22);
        layout.addView(title);

        learnerName = field("Learner name");
        grade = field("Grade");
        amount = field("Amount paid (KSh)");
        paymentMethod = field("Payment method (M-PESA / Bank)");
        layout.addView(learnerName);
        layout.addView(grade);
        layout.addView(amount);
        layout.addView(paymentMethod);

        Button generate = new Button(this);
        generate.setText("GENERATE PAYMENT SLIP");
        layout.addView(generate);

        slipNumber = new TextView(this);
        slipNumber.setTextSize(18);
        slipNumber.setPadding(0, 24, 0, 0);
        layout.addView(slipNumber);

        TextView details = new TextView(this);
        details.setTextSize(16);
        layout.addView(details);

        generate.setOnClickListener(v -> {
            String name = learnerName.getText().toString().trim();
            String g = grade.getText().toString().trim();
            String amt = amount.getText().toString().trim();
            String method = paymentMethod.getText().toString().trim();

            if (name.isEmpty() || g.isEmpty()) {
                slipNumber.setText("Enter the learner name and grade.");
                details.setText("");
                return;
            }

            String initials = getInitials(name);
            int year = Calendar.getInstance().get(Calendar.YEAR);
            int next = prefs.getInt("receipt_counter_" + year, 0) + 1;
            prefs.edit().putInt("receipt_counter_" + year, next).apply();

            String number = String.format(Locale.US, "%06d", next);
            String slip = "MMTJS/" + initials + "/" + g + "/" + year + "~" + number;

            slipNumber.setText("Slip No: " + slip);
            details.setText(
                "Learner: " + name +
                "\\nGrade: " + g +
                "\\nAmount: KSh " + amt +
                "\\nPayment method: " + method +
                "\\nYear: " + year
            );
        });

        setContentView(layout);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        return e;
    }

    private String getInitials(String name) {
        String[] parts = name.trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String p : parts) {
            if (!p.isEmpty()) {
                out.append(Character.toUpperCase(p.charAt(0)));
            }
        }
        return out.toString();
    }
}
