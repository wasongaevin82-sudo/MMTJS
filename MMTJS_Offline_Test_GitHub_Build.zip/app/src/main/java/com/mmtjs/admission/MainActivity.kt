package com.mmtjs.admission

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var result: TextView
    private val prefs by lazy { getSharedPreferences("mmtjs_offline", Context.MODE_PRIVATE) }

    private fun makeReference(): String {
        val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val number = (100000..999999).random()
        return "MMTJS-$date-$number"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        result = findViewById(R.id.result)
        val spinner: Spinner = findViewById(R.id.classSpinner)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("PP1","PP2","Grade 1","Grade 2","Grade 3","Grade 4","Grade 5","Grade 6"))

        findViewById<Button>(R.id.submit).setOnClickListener {
            val parentName = findViewById<EditText>(R.id.parentName).text.toString().trim()
            val parentPhone = findViewById<EditText>(R.id.parentPhone).text.toString().trim()
            val parentEmail = findViewById<EditText>(R.id.parentEmail).text.toString().trim()
            val learnerName = findViewById<EditText>(R.id.learnerName).text.toString().trim()
            val classLevel = spinner.selectedItem.toString()
            val dob = findViewById<EditText>(R.id.dob).text.toString().trim()
            val notes = findViewById<EditText>(R.id.notes).text.toString().trim()

            if (parentName.isBlank() || parentPhone.isBlank() || learnerName.isBlank()) {
                result.text = "Please complete the required parent and learner details."
                return@setOnClickListener
            }
            val ref = makeReference()
            val application = JSONObject().apply {
                put("reference", ref); put("parentName", parentName); put("parentPhone", parentPhone)
                put("parentEmail", parentEmail); put("learnerName", learnerName); put("classLevel", classLevel)
                put("dob", dob); put("notes", notes); put("status", "Submitted (Offline Test)")
                put("createdAt", System.currentTimeMillis())
            }
            prefs.edit().putString("app_$ref", application.toString()).putString("last_reference", ref).apply()
            result.text = "APPLICATION SAVED SUCCESSFULLY

Reference: $ref
Status: Submitted (Offline Test)

This test version stores the application on this phone only."
            findViewById<EditText>(R.id.reference).setText(ref)
        }

        findViewById<Button>(R.id.check).setOnClickListener {
            val ref = findViewById<EditText>(R.id.reference).text.toString().trim()
            if (ref.isBlank()) { result.text = "Enter your application reference first."; return@setOnClickListener }
            val saved = prefs.getString("app_$ref", null)
            if (saved == null) {
                result.text = "Application not found on this phone.

Make sure you are checking a reference created by this test app."
            } else {
                val j = JSONObject(saved)
                result.text = "APPLICATION FOUND

Reference: ${j.optString("reference")}
Learner: ${j.optString("learnerName")}
Class: ${j.optString("classLevel")}
Status: ${j.optString("status")}"
            }
        }
    }
}
