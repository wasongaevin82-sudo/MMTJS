# MMTJS Admission — Offline Test Android App

This version is designed for offline testing. It does **not** require internet access or a school server.

## What it does
- Parent/guardian admission form
- PP1, PP2 and Grade 1–6 selection
- Generates an MMTJS application reference
- Saves applications locally on the Android phone
- Checks saved application status offline
- Uses the MMTJS school logo and branding

## Important limitation
Applications are stored **only on the phone used for testing**. They are not sent to Mama Tetu Junior School. A future online release can connect the same app to the school's secure server.

## Build APK
Open this folder in Android Studio, allow Gradle to sync, then choose **Build > Build APK(s)**. The debug APK will normally be under `app/build/outputs/apk/debug/`.


## Build the APK from your phone with GitHub Actions

1. Upload the contents of this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build MMTJS APK**.
4. Tap **Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run and download the **MMTJS-APK** artifact.
7. Extract it on your phone and install `MMTJS.apk`.

This workflow creates a **debug APK** for testing. It is not a Play Store release build.
