package com.mmtjs.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText learnerName, grade, amount, paymentMethod;
    private TextView slipNumber, details;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("mmtjs_receipts", MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 28, 32, 28);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("MAMA TERTTU JUNIOR SCHOOL\nPAYMENT SLIP");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView slogan = new TextView(this);
        slogan.setText("It Can Be Done");
        slogan.setTextSize(16);
        slogan.setGravity(Gravity.CENTER);
        layout.addView(slogan);

        learnerName = field("Learner name");
        grade = field("Grade (1-6)");
        amount = field("Amount paid (KSh)");
        amount.setInputType(2 | 8192);
        paymentMethod = field("Payment method (M-PESA / Bank)");
        layout.addView(learnerName);
        layout.addView(grade);
        layout.addView(amount);
        layout.addView(paymentMethod);

        Button generate = new Button(this);
        generate.setText("GENERATE PAYMENT SLIP");
        layout.addView(generate);

        slipNumber = new TextView(this);
        slipNumber.setTextSize(18);
        slipNumber.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        slipNumber.setPadding(0, 24, 0, 0);
        layout.addView(slipNumber);

        details = new TextView(this);
        details.setTextSize(16);
        layout.addView(details);

        generate.setOnClickListener(v -> generateSlip());
        setContentView(layout);
    }

    private void generateSlip() {
        String name = learnerName.getText().toString().trim();
        String g = grade.getText().toString().trim();
        String amt = amount.getText().toString().trim();
        String method = paymentMethod.getText().toString().trim();

        if (name.isEmpty() || g.isEmpty()) {
            slipNumber.setText("Enter the learner name and grade.");
            details.setText("");
            return;
        }

        String initials = getInitials(name);
        if (initials.length() > 3) initials = initials.substring(0, 3);
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int next = prefs.getInt("receipt_counter_" + year, 0) + 1;
        prefs.edit().putInt("receipt_counter_" + year, next).apply();

        String number = String.format(Locale.US, "%06d", next);
        String slip = "MMTJS/" + initials + "/" + g + "/" + year + "~" + number;
        slipNumber.setText("Slip No: " + slip);
        details.setText("Learner: " + name +
                "\nGrade: " + g +
                "\nAmount: KSh " + (amt.isEmpty() ? "0" : amt) +
                "\nPayment method: " + (method.isEmpty() ? "Not specified" : method) +
                "\nYear: " + year);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setPadding(8, 10, 8, 10);
        return e;
    }

    private String getInitials(String name) {
        String[] parts = name.trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String p : parts) {
            if (!p.isEmpty()) out.append(Character.toUpperCase(p.charAt(0)));
        }
        return out.toString();
    }
}
