MMTJS FIXED PROJECT
===================
Mama Terttu Junior School
Slogan: It Can Be Done

This version fixes the launch crash caused by the previous AppCompatActivity/theme
combination by using the platform Activity class. It also fixes the school name
(TERTTU) and adds a proper MMTJS launcher icon.

Build with the included GitHub Actions workflow.
