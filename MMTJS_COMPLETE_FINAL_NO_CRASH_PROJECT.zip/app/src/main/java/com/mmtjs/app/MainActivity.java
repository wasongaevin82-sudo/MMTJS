
package com.mmtjs.app;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    final String NAVY="#0B2A78", BLUE="#1F5FAF", LIGHT="#EAF3FF", GOLD="#D6A62B";
    android.content.SharedPreferences sp;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("mmtjs",MODE_PRIVATE);
        showWelcome();
    }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.parseColor(NAVY));
        t.setPadding(12,10,12,10); return t;
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setPadding(16,10,16,10); return e; }

    void shell(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18); root.setBackgroundColor(Color.WHITE);
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView head=tv(title,22); head.setTextColor(Color.WHITE); head.setGravity(Gravity.CENTER);
        head.setBackgroundColor(Color.parseColor(NAVY)); head.setPadding(8,18,8,18);
        root.addView(head);
    }
    void logo(){
        ImageView im=new ImageView(this); im.setImageResource(com.mmtjs.app.R.drawable.mmtjs_logo);
        im.setAdjustViewBounds(true); im.setMaxHeight(220); im.setPadding(10,10,10,10);
        root.addView(im,new LinearLayout.LayoutParams(-1,220));
        TextView n=tv("MAMA TERTTU JUNIOR SCHOOL\nIt Can Be Done",20); n.setGravity(Gravity.CENTER);
        root.addView(n);
    }
    void add(View v){ root.addView(v,new LinearLayout.LayoutParams(-1,-2)); }

    void showWelcome(){
        shell("MMTJS");
        logo();
        add(tv("Welcome to Mama Terttu Junior School Parent App",19));
        Button login=btn("Parent Login"); login.setOnClickListener(v->showLogin()); add(login);
        Button reg=btn("Create Parent Account"); reg.setOnClickListener(v->showRegister()); add(reg);
        add(tv("School: 0722240469 / 0740655932\nEmail: mamaterttujuniorschool@gmail.com",14));
    }
    void showLogin(){
        shell("Parent Login"); logo();
        EditText phone=input("Phone number"); add(phone);
        EditText pass=input("Password"); pass.setInputType(0x81); add(pass);
        Button b=btn("LOGIN"); b.setOnClickListener(v->showDashboard()); add(b);
        Button f=btn("Forgot password / OTP"); f.setOnClickListener(v->showOtp()); add(f);
        Button r=btn("Register"); r.setOnClickListener(v->showRegister()); add(r);
    }
    void showRegister(){
        shell("Parent Registration"); logo();
        EditText name=input("Parent/Guardian full name"); add(name);
        EditText phone=input("Phone number"); add(phone);
        EditText email=input("Email"); add(email);
        EditText pass=input("Create password"); pass.setInputType(0x81); add(pass);
        Button b=btn("REGISTER"); b.setOnClickListener(v->{sp.edit().putBoolean("registered",true).apply(); showDashboard();}); add(b);
        add(tv("Test/offline registration is available. Live OTP requires the production backend.",13));
    }
    void showOtp(){
        shell("Password Recovery / OTP");
        add(tv("Enter your registered phone number. A production backend will send the OTP.",16));
        EditText p=input("Phone number"); add(p);
        Button send=btn("SEND OTP"); send.setOnClickListener(v->Toast.makeText(this,"Test OTP screen: use 123456",Toast.LENGTH_LONG).show()); add(send);
        EditText o=input("Enter OTP"); add(o);
        Button reset=btn("VERIFY OTP & RESET PASSWORD"); reset.setOnClickListener(v->showLogin()); add(reset);
    }

    void showDashboard(){
        shell("Parent Dashboard"); logo();
        add(tv("Welcome, Parent",19));
        Button learners=btn("👨‍👩‍👧 My Learners"); learners.setOnClickListener(v->showLearners()); add(learners);
        Button pay=btn("💳 PAY FOR 2026"); pay.setOnClickListener(v->showPay()); add(pay);
        Button services=btn("📥 Services & Downloads"); services.setOnClickListener(v->showServices()); add(services);
        Button bal=btn("📊 Fees Balance & Payment History"); bal.setOnClickListener(v->showBalance()); add(bal);
        Button more=btn("☰ More / Help"); more.setOnClickListener(v->showMore()); add(more);
        Button logout=btn("Logout"); logout.setOnClickListener(v->showWelcome()); add(logout);
    }
    void showLearners(){
        shell("My Learners");
        add(tv("No learner has been added yet, or select the demo learner below.",15));
        Button addl=btn("+ Add Learner"); addl.setOnClickListener(v->showAddLearner()); add(addl);
        Button demo=btn("Meshach Ochieng’ • Grade 6 • AD/2026/045"); demo.setOnClickListener(v->showPay()); add(demo);
        Button back=btn("Back to Dashboard"); back.setOnClickListener(v->showDashboard()); add(back);
    }
    void showAddLearner(){
        shell("Add Learner");
        EditText n=input("Learner full name"); add(n);
        EditText a=input("Admission number"); add(a);
        Spinner grade=new Spinner(this); grade.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ECDE","Grade 1","Grade 2","Grade 3","Grade 4","Grade 5","Grade 6"})); add(grade);
        EditText dob=input("Date of birth (optional)"); add(dob);
        Button save=btn("SAVE LEARNER"); save.setOnClickListener(v->showLearners()); add(save);
    }

    void showPay(){
        shell("PAY FOR 2026");
        add(tv("Select learner and payment details",17));
        Spinner term=new Spinner(this); term.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Term 1","Term 2","Term 3"})); add(term);
        Spinner fee=new Spinner(this); fee.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Tuition","Admission","Personnel","Materials","Meals","Assessment"})); add(fee);
        EditText amount=input("Amount (KSh)"); amount.setInputType(2|0x2000); add(amount);
        add(tv("Payment method",16));
        RadioGroup rg=new RadioGroup(this); RadioButton mp=new RadioButton(this); mp.setText("M-PESA"); RadioButton kb=new RadioButton(this); kb.setText("KCB"); rg.addView(mp); rg.addView(kb); mp.setChecked(true); add(rg);
        add(tv("School payment configuration:\nM-PESA route: 0722240469\nKCB: PayBill 522533 • Account 7961343\nThese destinations are not presented as editable fields to parents.",13));
        Button cont=btn("CONTINUE TO PAYMENT"); cont.setOnClickListener(v->showPaymentConfirm(amount.getText().toString(),mp.isChecked()?"M-PESA":"KCB")); add(cont);
    }
    void showPaymentConfirm(String amount,String method){
        shell("Payment Confirmation");
        add(tv("Amount: KSh "+(amount.length()==0?"0":amount)+"\nMethod: "+method,18));
        add(tv("The app will request provider confirmation. A payment is not marked CONFIRMED until the provider/backend returns a verified transaction.",14));
        Button pay=btn("SUBMIT PAYMENT REQUEST"); pay.setOnClickListener(v->{
            Toast.makeText(this,"Payment request recorded as PENDING in this APK build.",Toast.LENGTH_LONG).show();
            showSlip(false,method,amount,"PENDING","PENDING");
        }); add(pay);
        Button back=btn("Back"); back.setOnClickListener(v->showPay()); add(back);
    }

    void showServices(){
        shell("Services & Downloads");
        add(tv("Available services",19));
        Button slips=btn("📄 Payment Slips"); slips.setOnClickListener(v->showSlip(true,"M-PESA","5000","Confirmed","MPESA712345678")); add(slips);
        Button fees=btn("📋 Fee Structure"); fees.setOnClickListener(v->Toast.makeText(this,"Fee structure module ready for school-configured values.",Toast.LENGTH_LONG).show()); add(fees);
        Button docs=btn("📥 Download Documents"); docs.setOnClickListener(v->Toast.makeText(this,"Document download area ready for backend documents.",Toast.LENGTH_LONG).show()); add(docs);
        Button back=btn("Dashboard"); back.setOnClickListener(v->showDashboard()); add(back);
    }
    void showBalance(){
        shell("Fees Balance & Payment History");
        add(tv("2026 Balance",20));
        add(tv("Term 1\nOpening balance: KSh 20,000.00\nPaid: KSh 5,000.00\nBalance: KSh 15,000.00",17));
        add(tv("Payment history",18));
        add(tv("20/09/2026 • Tuition • KSh 5,000.00 • M-PESA • Confirmed",14));
        Button s=btn("Open / Download Payment Slip"); s.setOnClickListener(v->showSlip(true,"M-PESA","5000","Confirmed","MPESA712345678")); add(s);
        Button back=btn("Dashboard"); back.setOnClickListener(v->showDashboard()); add(back);
    }

    String initials(String name){
        String[] p=name.trim().split("\\s+"); if(p.length==0)return "XX";
        String r=""+Character.toUpperCase(p[0].charAt(0));
        if(p.length>1) r+=Character.toUpperCase(p[p.length-1].charAt(0));
        return r;
    }
    String slipNo(){ return "MMTJS/MO/6/2026~000001"; }

    void showSlip(boolean confirmed,String method,String amount,String status,String ref){
        shell("Payment Slip");
        add(tv("MMTJS PAYMENT SLIP",22));
        SlipView sv=new SlipView(this,confirmed,method,amount,status,ref); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        Button pdf=btn("⬇ Download PDF"); pdf.setOnClickListener(v->makePdf(confirmed,method,amount,status,ref)); add(pdf);
        Button back=btn("Back"); back.setOnClickListener(v->showDashboard()); add(back);
    }

    class SlipView extends View {
        Paint p=new Paint(3); Bitmap logo,sig;
        boolean confirmed; String method,amount,status,ref;
        SlipView(Context c,boolean co,String m,String a,String st,String r){super(c);confirmed=co;method=m;amount=a;status=st;ref=r;
            logo=BitmapFactory.decodeResource(getResources(),R.drawable.mmtjs_logo);
            sig=BitmapFactory.decodeResource(getResources(),R.drawable.bursar_signature);
            setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        }
        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);c.drawText(s,x,y,p);}
        @Override protected void onDraw(Canvas c){
            int W=getWidth(); p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawRect(0,0,W,getHeight(),p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.parseColor(NAVY));c.drawRoundRect(6,6,W-6,getHeight()-6,14,14,p);
            p.setStyle(Paint.Style.FILL);
            Rect dst=new Rect(20,20,170,170);c.drawBitmap(logo,null,dst,p);
            txt(c,"MAMA TERTTU",185,65,25,Color.parseColor(NAVY),true);
            txt(c,"JUNIOR SCHOOL",185,96,25,Color.parseColor(NAVY),true);
            txt(c,"It Can Be Done",185,124,18,Color.parseColor(BLUE),false);
            txt(c,"0722240469 / 0740655932",185,149,12,Color.DKGRAY,false);
            txt(c,"mamaterttujuniorschool@gmail.com",185,166,11,Color.DKGRAY,false);
            p.setColor(Color.parseColor(NAVY));c.drawRect(12,182,W-12,225,p);
            txt(c,"PAYMENT SLIP",W/2-85,210,21,Color.WHITE,true);

            // Watermark
            p.setAlpha(32); c.drawBitmap(logo,null,new Rect(W/2-120,250,W/2+120,490),p);p.setAlpha(255);
            float y=260;
            String[][] rows={{"Slip No",slipNo()},{"Date",new SimpleDateFormat("dd/MM/yyyy  hh:mm a",Locale.US).format(new Date())},
                {"Learner Name","Meshach Ochieng’"},{"Admission No","AD/2026/045"},{"Grade","6"},{"Term","Term 1"}};
            for(String[] row:rows){txt(c,row[0],25,y,14,Color.parseColor(BLUE),true);txt(c,":",145,y,14,Color.DKGRAY,true);txt(c,row[1],160,y,14,Color.DKGRAY,false);y+=30;}
            p.setColor(Color.parseColor(LIGHT));c.drawRect(18,y-20,W-18,y+20,p);txt(c,"PAYMENT DETAILS",30,y+7,15,Color.parseColor(NAVY),true);y+=55;
            String[][] pay={{"Fee Item","Tuition"},{"Amount","KSh "+(amount.length()==0?"0.00":amount+".00")},{"Payment Method",method},
                {"Transaction Ref",ref},{"Payment Date",new SimpleDateFormat("dd/MM/yyyy  hh:mm a",Locale.US).format(new Date())},
                {"Status",status},{"Balance After Payment","KSh 15,000.00"}};
            for(String[] row:pay){txt(c,row[0],25,y,13,Color.parseColor(BLUE),true);txt(c,":",145,y,13,Color.DKGRAY,true);
                int col=row[0].equals("Status")&&confirmed?Color.parseColor("#16823B"):Color.DKGRAY;txt(c,row[1],160,y,13,col,false);y+=27;}
            p.setColor(Color.parseColor(LIGHT));c.drawRoundRect(20,y,W-20,y+65,10,10,p);
            txt(c,"Thank you for your payment.",W/2-105,y+25,13,Color.parseColor(BLUE),false);
            txt(c,"Together we build a brighter future for our children.",W/2-145,y+46,10,Color.parseColor(BLUE),false);
            y+=92;
            txt(c,"▣",30,y+20,45,Color.BLACK,false);txt(c,"Scan to verify",95,y+12,13,Color.parseColor(BLUE),true);
            txt(c,"this payment slip",95,y+32,13,Color.parseColor(BLUE),false);txt(c,"or download a PDF",95,y+52,13,Color.parseColor(BLUE),false);
            if(sig!=null)c.drawBitmap(sig,null,new Rect(W-190,y,W-30,y+80),p);
            txt(c,"BURSAR",W-125,y+95,14,Color.parseColor(NAVY),true);
            p.setColor(Color.parseColor(NAVY));c.drawRect(12,getHeight()-48,W-12,getHeight()-12,p);txt(c,"It Can Be Done",W/2-55,getHeight()-24,14,Color.WHITE,false);
        }
    }

    void makePdf(boolean confirmed,String method,String amount,String status,String ref){
        try{
            int w=595,h=842; android.graphics.pdf.PdfDocument doc=new android.graphics.pdf.PdfDocument();
            android.graphics.pdf.PdfDocument.Page page=doc.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(w,h,1).create());
            Canvas c=page.getCanvas(); Paint p=new Paint(3);
            p.setColor(Color.WHITE);c.drawRect(0,0,w,h,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.parseColor(NAVY));c.drawRoundRect(8,8,w-8,h-8,12,12,p);p.setStyle(Paint.Style.FILL);
            Bitmap logo=BitmapFactory.decodeResource(getResources(),R.drawable.mmtjs_logo);c.drawBitmap(logo,null,new Rect(25,25,145,145),p);
            Paint t=new Paint(3);t.setColor(Color.parseColor(NAVY));t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setTextSize(24);c.drawText("MAMA TERTTU",160,62,t);c.drawText("JUNIOR SCHOOL",160,92,t);
            t.setTypeface(Typeface.DEFAULT);t.setTextSize(14);c.drawText("It Can Be Done",160,118,t);t.setTextSize(10);c.drawText("0722240469 / 0740655932",160,137,t);c.drawText("mamaterttujuniorschool@gmail.com",160,151,t);
            p.setColor(Color.parseColor(NAVY));c.drawRect(18,170,w-18,215,p);t.setColor(Color.WHITE);t.setTextSize(20);t.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("PAYMENT SLIP",220,200,t);
            p.setAlpha(28);c.drawBitmap(logo,null,new Rect(170,280,425,535),p);p.setAlpha(255);
            t.setColor(Color.DKGRAY);t.setTextSize(12);t.setTypeface(Typeface.DEFAULT);
            String[] lines={"Slip No : "+slipNo(),"Learner Name : Meshach Ochieng’","Admission No : AD/2026/045","Grade : 6","Term : Term 1",
            "Fee Item : Tuition","Amount : KSh "+(amount.length()==0?"0.00":amount+".00"),"Payment Method : "+method,"Transaction Ref : "+ref,
            "Status : "+status,"Balance After Payment : KSh 15,000.00"};
            int y=250; for(String line:lines){c.drawText(line,35,y,t);y+=31;}
            t.setColor(Color.parseColor(BLUE));t.setTextSize(14);c.drawText("Thank you for your payment.",170,635,t);
            t.setTextSize(10);c.drawText("Scan to verify this payment slip or download a PDF",150,660,t);
            Bitmap sig=BitmapFactory.decodeResource(getResources(),R.drawable.bursar_signature);c.drawBitmap(sig,null,new Rect(400,675,560,735),p);
            t.setColor(Color.parseColor(NAVY));t.setTypeface(Typeface.DEFAULT_BOLD);t.setTextSize(13);c.drawText("BURSAR",470,752,t);
            p.setColor(Color.parseColor(NAVY));c.drawRect(18,800,w-18,830,p);t.setColor(Color.WHITE);t.setTypeface(Typeface.DEFAULT);c.drawText("It Can Be Done",250,820,t);
            doc.finishPage(page);
            File f=new File(getExternalFilesDir(null),"MMTJS_"+slipNo().replace("/","_").replace("~","_")+".pdf");
            FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();
            Toast.makeText(this,"PDF saved inside MMTJS app storage:\n"+f.getName(),Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"PDF error: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void showMore(){
        shell("More / Help");
        add(tv("Mama Terttu Junior School",20));add(tv("Phone: 0722240469 / 0740655932\nEmail: mamaterttujuniorschool@gmail.com",15));
        Button call=btn("Call School");call.setOnClickListener(v->{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:0722240469")));});add(call);
        Button email=btn("Email School");email.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:mamaterttujuniorschool@gmail.com"));startActivity(i);});add(email);
        add(tv("Help\n• Payments are confirmed only after provider verification.\n• Keep your payment slip for your records.\n• Contact the school if a payment remains pending.",14));
        Button del=btn("Delete local account data");del.setOnClickListener(v->{sp.edit().clear().apply();showWelcome();});add(del);
        Button back=btn("Dashboard");back.setOnClickListener(v->showDashboard());add(back);
    }
}
