# MMTJS Complete Android Project

Mama Terttu Junior School parent Android application.

## Included
- Parent Login
- Parent Registration
- OTP/password recovery test screen
- Parent Dashboard
- Learners / Add Learner
- PAY FOR 2026
- Term and fee/vote-head selection
- M-PESA and KCB payment routes
- Payment status/history
- Services and Downloads
- Fees Balance
- Payment Slip
- PDF download
- Official MMTJS logo and Android app icon
- School logo watermark on slips
- Bursar signature
- QR/verification area on slip
- More/Help and school contacts
- Automatic slip-number format: MMTJS/[initials]/[grade]/[year]~[six digits]

## Payment configuration
M-PESA route supplied by the school: 0722240469
KCB: PayBill 522533, Account 7961343

IMPORTANT: this source does not pretend that an APK can directly and securely move money using a personal M-PESA number. Production automatic payments require the school's approved Safaricom/KCB merchant/API arrangement and secure backend credentials. Provider secrets must never be embedded in the APK.

The APK therefore records payment requests as PENDING until a real provider/backend confirmation is connected.

## Build
Use Gradle 8.9+ and Android Gradle Plugin 8.7.3, Java 17, compile SDK 35.
The GitHub Actions workflow installs the required Android SDK and Gradle, extracts this project, and builds app-debug.apk.

The approved payment slip reference image is included as approved_payment_slip_reference.png.

## Stability / crash prevention
- Single-activity Java implementation with no external runtime libraries.
- No AndroidX FileProvider dependency.
- Uses Java 17 explicitly; AGP 8.7.x requires JDK 17.
- No provider secrets or payment credentials are embedded.
- PDF is generated using Android's built-in PdfDocument API.
- The official logo is bundled in the APK resources.
