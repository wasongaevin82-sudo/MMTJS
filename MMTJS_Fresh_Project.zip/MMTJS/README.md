# MMTJS

Fresh Android starter project for Mama Tetu Junior School.

## Current starter screens
- Parent login
- Parent sign-up
- Dashboard
- Learner registration
- Payment selection
- M-PESA / Bank payment placeholders
- Services: Status, Downloads, Terms Balance
- More: Change password, Log out, Delete account
- Help

## Security note
The school's real payment destination details are intentionally not displayed in the parent UI.
Live M-PESA/Bank transactions and verification must be connected through a secure backend/payment integration before production use.

## Build
The included GitHub Actions workflow builds a debug APK.
