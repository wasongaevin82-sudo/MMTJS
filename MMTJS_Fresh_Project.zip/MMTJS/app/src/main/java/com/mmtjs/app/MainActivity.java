package com.mmtjs.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title;
    int gold = Color.rgb(184,134,11);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showLogin();
    }

    TextView tv(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(20, 12, 20, 12);
        return t;
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setPadding(20, 8, 20, 8);
        return e;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    void base(String screenTitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        title = tv(screenTitle, 22);
        title.setTextColor(Color.WHITE);
        title.setBackgroundColor(gold);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 64));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 24, 24, 24);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    void showLogin() {
        base("MMTJS — Parent Login");
        content.addView(tv("MAMA TETU JUNIOR SCHOOL", 24));
        content.addView(tv("Parent Portal", 18));

        EditText user = field("Username / Phone number");
        EditText pass = field("Password");
        pass.setInputType(0x81);
        content.addView(user);
        content.addView(pass);

        Button login = btn("LOG IN");
        content.addView(login);
        login.setOnClickListener(v -> showHome(user.getText().toString().trim()));

        Button signup = btn("Create account");
        content.addView(signup);
        signup.setOnClickListener(v -> showSignup());

        Button forgot = btn("Forgot password?");
        content.addView(forgot);
        forgot.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("Password recovery")
                .setMessage("OTP recovery will be connected to the registered phone number in the secure backend.")
                .setPositiveButton("OK", null).show();
        });
    }

    void showSignup() {
        base("Create Parent Account");
        EditText first = field("First name");
        EditText middle = field("Middle name");
        EditText id = field("ID number");
        EditText phone = field("Phone number");
        EditText p1 = field("New password");
        EditText p2 = field("Confirm password");
        p1.setInputType(0x81); p2.setInputType(0x81);

        content.addView(first); content.addView(middle); content.addView(id);
        content.addView(phone); content.addView(p1); content.addView(p2);

        Button submit = btn("SUBMIT");
        content.addView(submit);
        submit.setOnClickListener(v -> {
            if (first.getText().length()==0 || phone.getText().length()==0 || p1.getText().length()==0) {
                Toast.makeText(this, "Please complete the required fields.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!p1.getText().toString().equals(p2.getText().toString())) {
                Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_LONG).show();
                return;
            }
            Toast.makeText(this, "Account details accepted for setup.", Toast.LENGTH_LONG).show();
            showHome((first.getText().toString()+" "+middle.getText().toString()).trim());
        });
        Button back = btn("← Back to login");
        content.addView(back);
        back.setOnClickListener(v -> showLogin());
    }

    void showHome(String name) {
        base("MMTJS");
        content.addView(tv("Welcome, " + (name.isEmpty() ? "Parent" : name), 24));
        content.addView(tv("Mama Tetu Junior School", 18));
        content.addView(tv("Parent dashboard", 16));

        Button learners = btn("👨‍🎓 Add / View Learners");
        Button payment = btn("💳 Payments");
        Button services = btn("⚙ Services");
        Button more = btn("☷ More");
        Button help = btn("? Help");

        content.addView(learners); content.addView(payment);
        content.addView(services); content.addView(more); content.addView(help);

        learners.setOnClickListener(v -> showLearner());
        payment.setOnClickListener(v -> showPayment());
        services.setOnClickListener(v -> showServices());
        more.setOnClickListener(v -> showMore());
        help.setOnClickListener(v -> showHelp());
    }

    void showLearner() {
        base("Learners");
        content.addView(tv("Add Learner Details", 22));
        EditText first = field("Learner first name");
        EditText middle = field("Learner middle name");
        EditText last = field("Learner last name (optional)");
        EditText adm = field("Admission number");
        EditText grade = field("Grade / Class");
        EditText dob = field("Date of birth (optional)");
        content.addView(first); content.addView(middle); content.addView(last);
        content.addView(adm); content.addView(grade); content.addView(dob);

        Button submit = btn("SUBMIT");
        content.addView(submit);
        submit.setOnClickListener(v -> Toast.makeText(this,
            "Learner details saved locally for this starter version.", Toast.LENGTH_LONG).show());

        Button back = btn("← Home");
        content.addView(back);
        back.setOnClickListener(v -> showHome(""));
    }

    void showPayment() {
        base("Payments");
        content.addView(tv("Select learner", 20));
        Spinner learner = new Spinner(this);
        learner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Select learner", "Example Learner — Grade 6"}));
        content.addView(learner);

        content.addView(tv("Select term", 20));
        Spinner term = new Spinner(this);
        term.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Term 1", "Term 2", "Term 3"}));
        content.addView(term);

        content.addView(tv("Payment category / vote head", 20));
        Spinner vote = new Spinner(this);
        vote.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Tuition", "Admission", "Personnel Emoluments", "Education Materials", "Meals", "Assessment Fee"}));
        content.addView(vote);

        EditText amount = field("Amount to pay (KSh)");
        content.addView(amount);

        Button mpesa = btn("PAY WITH M-PESA");
        Button bank = btn("PAY BY BANK");
        content.addView(mpesa); content.addView(bank);

        View.OnClickListener pay = v -> {
            String method = v == mpesa ? "M-PESA" : "BANK";
            new AlertDialog.Builder(this)
                .setTitle("Payment")
                .setMessage("Payment method: " + method +
                    "\n\nThe school's payment destination is securely configured and is NOT displayed to parents." +
                    "\n\nLive payment verification will be connected through a secure backend.")
                .setPositiveButton("CONTINUE", null).show();
        };
        mpesa.setOnClickListener(pay); bank.setOnClickListener(pay);

        Button back = btn("← Home");
        content.addView(back);
        back.setOnClickListener(v -> showHome(""));
    }

    void showServices() {
        base("Services");
        Button status = btn("Status");
        Button downloads = btn("Downloads");
        Button balance = btn("Terms Balance");
        content.addView(status); content.addView(downloads); content.addView(balance);
        status.setOnClickListener(v -> showStatus());
        downloads.setOnClickListener(v -> showDownloads());
        balance.setOnClickListener(v -> showBalance());
    }

    void showStatus() {
        base("Payment Status");
        content.addView(tv("Learner: Example Learner — Grade 6", 18));
        content.addView(tv("Payment status will appear here after verified transactions.", 16));
        Button back = btn("← Services");
        content.addView(back);
        back.setOnClickListener(v -> showServices());
    }

    void showDownloads() {
        base("Downloads");
        content.addView(tv("Available downloads", 20));
        Button ecde = btn("Download ECDE Fee Structure");
        Button primary = btn("Download Primary Fee Structure");
        Button slips = btn("Payment Slips");
        content.addView(ecde); content.addView(primary); content.addView(slips);
        Toast.makeText(this, "Download files will be supplied by administration.", Toast.LENGTH_LONG).show();
    }

    void showBalance() {
        base("Terms Balance");
        content.addView(tv("Learner: Example Learner", 20));
        content.addView(tv("Vote Head                 Paid        Balance", 16));
        content.addView(tv("Admission                  —            —", 16));
        content.addView(tv("Meals                         —            —", 16));
        content.addView(tv("Tuition                       —            —", 16));
        content.addView(tv("Balances update automatically after verified payments.", 15));
    }

    void showMore() {
        base("More");
        Button change = btn("Change password");
        Button logout = btn("Log out");
        Button delete = btn("Delete account");
        content.addView(change); content.addView(logout); content.addView(delete);
        change.setOnClickListener(v -> Toast.makeText(this, "Password change will be connected to the secure account service.", Toast.LENGTH_LONG).show());
        logout.setOnClickListener(v -> showLogin());
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Delete account")
            .setMessage("This will permanently remove the parent account after secure confirmation.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("DELETE", (d,w) -> showLogin()).show());
    }

    void showHelp() {
        base("Help");
        content.addView(tv("For assistance, use the official school support contacts configured by administration.", 18));
        Button call1 = btn("Call support");
        Button call2 = btn("Call alternative support");
        content.addView(call1); content.addView(call2);
        call1.setOnClickListener(v -> Toast.makeText(this, "Support contact will be configured by administration.", Toast.LENGTH_LONG).show());
        call2.setOnClickListener(v -> Toast.makeText(this, "Support contact will be configured by administration.", Toast.LENGTH_LONG).show());
    }
}
