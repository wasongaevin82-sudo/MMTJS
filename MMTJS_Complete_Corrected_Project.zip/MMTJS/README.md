# MMTJS Complete Corrected Android Project

Mama Terttu Junior School — parent-facing Android app foundation.

## Included
- Welcome/login/register screen
- Parent dashboard
- Add learner
- Learner list and selection
- PAY FOR 2026 screen
- Term and fee/vote-head selection
- M-PESA / Bank payment method (destination details hidden)
- Offline payment confirmation and payment slip generation
- Slip format: MMTJS/[learner initials]/[grade]/[year]~[six-digit sequence]
- Services: balances, payment slips, fee structures/download placeholder
- More/Help: school contacts, change password, logout, delete local account
- Mama Terttu Junior School logo included and used as launcher icon
- Offline-first local storage using SharedPreferences

## Build
The project intentionally does not require the Gradle wrapper. The GitHub workflow in `.github/workflows/build-apk.yml` installs Gradle 8.7 and builds the project.

This version is an offline test/foundation app. It does not perform live M-PESA or bank transactions. Live payment-provider integration can be added later.
