package com.mmtjs.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BROWN = Color.rgb(122,82,0), GOLD = Color.rgb(184,134,11), DARK = Color.rgb(45,45,45), LIGHT = Color.rgb(255,249,232);
    private LinearLayout root, content;
    private SharedPreferences prefs;
    private String selectedLearner = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("mmtjs", MODE_PRIVATE);
        showWelcome();
    }

    private TextView text(String s, float size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(DARK); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(12,10,12,10); return t;
    }
    private Button btn(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(14); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundColor(BROWN); b.setPadding(12,4,12,4); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,52); p.setMargins(16,6,16,6); b.setLayoutParams(p); return b; }
    private EditText input(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(true); e.setPadding(16,4,16,4); e.setLayoutParams(new LinearLayout.LayoutParams(-1,52)); return e; }
    private void base(String title) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(BROWN); bar.setPadding(8,4,8,4);
        TextView back=text("‹",34,false); back.setTextColor(Color.WHITE); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->showDashboard()); bar.addView(back,new LinearLayout.LayoutParams(50,60));
        TextView tt=text(title,19,true); tt.setTextColor(Color.WHITE); bar.addView(tt,new LinearLayout.LayoutParams(0,60,1)); root.addView(bar);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(10,12,10,30); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    private void logoHeader() {
        ImageView iv=new ImageView(this); iv.setImageResource(com.mmtjs.app.R.drawable.mmtjs_logo); iv.setAdjustViewBounds(true); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); content.addView(iv,new LinearLayout.LayoutParams(-1,180));
        TextView n=text("MAMA TERTTU JUNIOR SCHOOL",23,true); n.setTextColor(BROWN); content.addView(n); TextView s=text("It Can Be Done",16,false); s.setTextColor(GOLD); content.addView(s);
    }
    private void showWelcome() {
        base("Welcome"); logoHeader();
        content.addView(text("Parent & School Services",20,true));
        Button login=btn("Parent Login"); login.setOnClickListener(v->showLogin()); content.addView(login);
        Button reg=btn("Create Parent Account"); reg.setOnClickListener(v->showRegister()); content.addView(reg);
        content.addView(text("Offline test version • Your information is stored on this phone.",13,false));
    }
    private void showLogin() {
        base("Parent Login"); logoHeader(); EditText phone=input("Phone number"); EditText pass=input("Password"); pass.setInputType(129); content.addView(phone); content.addView(pass);
        Button b=btn("LOGIN"); b.setOnClickListener(v->{ if(phone.getText().length()==0||pass.getText().length()==0){toast("Enter phone and password");return;} showDashboard();}); content.addView(b);
        Button f=btn("Forgot Password / OTP"); f.setOnClickListener(v->showForgot()); content.addView(f);
        Button r=btn("Create New Account"); r.setOnClickListener(v->showRegister()); content.addView(r);
    }
    private void showRegister() {
        base("Parent Registration"); logoHeader(); EditText name=input("Parent full name"); EditText phone=input("Phone number"); EditText email=input("Email address"); EditText pass=input("Create password"); pass.setInputType(129); content.addView(name);content.addView(phone);content.addView(email);content.addView(pass);
        Button b=btn("REGISTER"); b.setOnClickListener(v->{if(name.getText().length()==0||phone.getText().length()==0||pass.getText().length()==0){toast("Complete the required fields");return;} prefs.edit().putBoolean("registered",true).apply(); toast("Account created on this device"); showDashboard();}); content.addView(b);
    }
    private void showForgot(){ base("Password Recovery"); logoHeader(); EditText p=input("Phone number"); content.addView(p); Button b=btn("SEND OTP"); b.setOnClickListener(v->{toast("Test OTP sent. Contact the school for live OTP setup."); showDashboard();}); content.addView(b); }

    private void showDashboard(){
        base("Parent Dashboard"); logoHeader(); content.addView(text("Welcome to your MMTJS parent dashboard",18,true));
        Button learners=btn("👤  My Learners"); learners.setOnClickListener(v->showLearners()); content.addView(learners);
        Button add=btn("＋  Add Learner"); add.setOnClickListener(v->showAddLearner()); content.addView(add);
        Button pay=btn("💳  PAY FOR 2026"); pay.setOnClickListener(v->showPayment()); content.addView(pay);
        Button services=btn("📄  Services & Documents"); services.setOnClickListener(v->showServices()); content.addView(services);
        Button more=btn("☰  More / Help"); more.setOnClickListener(v->showMore()); content.addView(more);
    }
    private void showAddLearner(){
        base("Add Learner"); TextView info=text("Enter learner details",18,true); content.addView(info);
        EditText name=input("Learner full name"); EditText adm=input("Admission number"); EditText grade=input("Grade (1-6)"); EditText dob=input("Date of birth (optional)"); content.addView(name);content.addView(adm);content.addView(grade);content.addView(dob);
        Button b=btn("SAVE LEARNER"); b.setOnClickListener(v->{if(name.getText().length()==0||grade.getText().length()==0){toast("Enter learner name and grade");return;} prefs.edit().putString("learner_name",name.getText().toString()).putString("admission",adm.getText().toString()).putString("grade",grade.getText().toString()).putString("dob",dob.getText().toString()).apply(); selectedLearner=name.getText().toString(); toast("Learner saved"); showLearners();}); content.addView(b);
    }
    private void showLearners(){
        base("My Learners"); String n=prefs.getString("learner_name",""); if(n.isEmpty()){content.addView(text("No learner has been added yet.",17,true)); Button a=btn("ADD LEARNER"); a.setOnClickListener(v->showAddLearner()); content.addView(a); return;}
        TextView card=text("Learner: "+n+"\nAdmission: "+prefs.getString("admission","Not set")+"\nGrade: "+prefs.getString("grade",""),17,true); card.setBackgroundColor(LIGHT); content.addView(card);
        Button pay=btn("PAY FOR THIS LEARNER"); pay.setOnClickListener(v->{selectedLearner=n;showPayment();}); content.addView(pay);
    }
    private void showPayment(){
        base("PAY FOR 2026"); String n=prefs.getString("learner_name",""); if(n.isEmpty()){content.addView(text("Please add a learner first.",17,true)); Button a=btn("ADD LEARNER"); a.setOnClickListener(v->showAddLearner()); content.addView(a); return;}
        selectedLearner=n; content.addView(text("Learner: "+n,18,true));
        Spinner term=new Spinner(this); String[] terms={"Term 1","Term 2","Term 3"}; term.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,terms)); content.addView(term);
        Spinner head=new Spinner(this); String[] heads={"Tuition","Admission","Personnel","Materials","Meals","Assessment"}; head.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,heads)); content.addView(head);
        EditText amount=input("Amount (KSh)"); content.addView(amount);
        Spinner method=new Spinner(this); String[] methods={"M-PESA","Bank"}; method.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,methods)); content.addView(method);
        content.addView(text("Payment destination details are kept out of the parent interface. This offline build records the selected method and amount only.",13,false));
        EditText ref=input("Payment/reference number (optional for test)"); content.addView(ref);
        Button b=btn("CONFIRM PAYMENT & GENERATE SLIP"); b.setOnClickListener(v->{if(amount.getText().length()==0){toast("Enter the amount");return;} generateSlip(term.getSelectedItem().toString(),head.getSelectedItem().toString(),amount.getText().toString(),method.getSelectedItem().toString(),ref.getText().toString());}); content.addView(b);
    }
    private void generateSlip(String term,String head,String amount,String method,String ref){
        int seq=prefs.getInt("slip_seq",0)+1; prefs.edit().putInt("slip_seq",seq).putString("last_slip_amount",amount).putString("last_slip_method",method).putString("last_slip_term",term).putString("last_slip_head",head).putString("last_slip_ref",ref).apply(); showSlip(seq); }
    private String initials(String n){String[] a=n.trim().split("\\s+"); if(a.length==1)return a[0].substring(0,Math.min(2,a[0].length())).toUpperCase(Locale.US); return (a[0].substring(0,1)+a[a.length-1].substring(0,1)).toUpperCase(Locale.US);}
    private void showSlip(int seq){
        base("Payment Slip"); ImageView iv=new ImageView(this); iv.setImageResource(R.drawable.mmtjs_logo); iv.setAdjustViewBounds(true); content.addView(iv,new LinearLayout.LayoutParams(-1,150));
        int year=Calendar.getInstance().get(Calendar.YEAR); String grade=prefs.getString("grade","1"); String slip=String.format(Locale.US,"MMTJS/%s/%s/%d~%06d",initials(selectedLearner),grade,year,seq);
        content.addView(text("MAMA TERTTU JUNIOR SCHOOL",23,true)); content.addView(text("PAYMENT SLIP",21,true)); content.addView(text("It Can Be Done",16,false));
        TextView s=text("Slip Number\n"+slip+"\n\nLearner: "+selectedLearner+"\nGrade: "+grade+"\nTerm: "+prefs.getString("last_slip_term","")+"\nFee/Vote Head: "+prefs.getString("last_slip_head","")+"\nAmount Paid: KSh "+prefs.getString("last_slip_amount","")+"\nPayment Method: "+prefs.getString("last_slip_method","")+"\nReference: "+prefs.getString("last_slip_ref","Not supplied")+"\n\nSTATUS: RECORDED FOR OFFLINE TEST",17,true); s.setBackgroundColor(LIGHT); content.addView(s);
        Button again=btn("MAKE ANOTHER PAYMENT"); again.setOnClickListener(v->showPayment()); content.addView(again); Button share=btn("SHARE SLIP TEXT"); share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s.getText().toString());startActivity(Intent.createChooser(i,"Share payment slip"));}); content.addView(share);
    }
    private void showServices(){
        base("Services & Documents"); content.addView(text("School services",20,true));
        Button bal=btn("Fees Balance"); bal.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Fees Balance").setMessage("Offline test: live balance is not connected yet. Your school server/payment provider can be connected in the next phase.").setPositiveButton("OK",null).show();}); content.addView(bal);
        Button slips=btn("Payment Slips"); slips.setOnClickListener(v->{if(prefs.getInt("slip_seq",0)>0)showSlip(prefs.getInt("slip_seq",1));else toast("No payment slip recorded yet");}); content.addView(slips);
        Button fee=btn("Fee Structure"); fee.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Fee Structure").setMessage("2026 fee structure placeholder. School administration can update the official amounts when the online database is connected.").setPositiveButton("OK",null).show();}); content.addView(fee);
        Button down=btn("Downloads / Documents"); down.setOnClickListener(v->toast("Documents will appear here when connected to the school service.") ); content.addView(down);
    }
    private void showMore(){
        base("More / Help"); content.addView(text("MAMA TERTTU JUNIOR SCHOOL",22,true)); content.addView(text("It Can Be Done",16,false));
        Button help=btn("Call School: 0722240469"); help.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0722240469"));startActivity(i);}); content.addView(help);
        Button help2=btn("Call School: 0740655932"); help2.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0740655932"));startActivity(i);}); content.addView(help2);
        Button email=btn("Email: mamaterttujuniorschool@gmail.com"); email.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:mamaterttujuniorschool@gmail.com"));startActivity(i);}); content.addView(email);
        Button cp=btn("Change Password"); cp.setOnClickListener(v->toast("Password change will be connected to the secure online account service.")); content.addView(cp);
        Button logout=btn("Logout"); logout.setOnClickListener(v->showWelcome()); content.addView(logout);
        Button del=btn("Delete Local Account"); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete local account?").setMessage("This removes the offline test data stored on this phone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{prefs.edit().clear().apply();showWelcome();}).show()); content.addView(del);
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){showDashboard();}
}
